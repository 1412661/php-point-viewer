function analyze_db(mode) {
	var db_id = $('input[name="db_id"]').val(); 
	if (mode == "statistic") {
	
	window.location.href = "statistic.php?db_id=" + db_id;
	} else {
		if (mode = "class_rank") {
		window.location.href = "class_rank.php?action=view_rank&db_id=" + db_id;
		}
	}
}
function popup(w,h) {
	var left = (screen.width - w) / 2;
	var top = (screen.height - h) / 2;
	newwindow = window.open('contact.php', 'Contac Me', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=670, height=490, top='+top+', left='+left);
}function share_fb(link) {	newwindow = window.open(link, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=800, height=400');}$(document).ready(function() {	$(function() {		$("#t1, #t2, #t3").tabs();	});});checked = false;function checkedAll (frm) {	var frm = document.getElementById(frm);	if (checked == false) {		checked = true	} else {		checked = false	}		for (var i = 0; i < frm.elements.length; i++) {		frm.elements[i].checked = checked;	}}function toggle(id) {   $("#"+id).toggle();}