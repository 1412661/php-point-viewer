﻿<?php/*	Đây là file tạo biểu đồ tổng hợp điểm khi bạn xem bảng điểm xếp hạng tập thể lớp*/
session_start();
if ((!isset($_SESSION['chart'])) or (!isset($_SESSION['db_id']))) {
	die();
}
include_once('config/config.php');
include_once('class/chart.class.php');
include_once('class/xtemplate/xtemplate.class.php');
include_once('function/function.php');
if (!DEV_MODE) {
	error_reporting(E_ERROR | E_WARNING | E_PARSE);
}
$chart = array(
	'total_point'		=>	array(),
	'total_add_point'	=>	array(),
	'total_subtr_point'	=>	array()
);
foreach ($_SESSION['chart'] as $class => $class_name) {
	$chart['total_point'][$class] = $class_name['total_point'];
	$chart['total_add_point'][$class] = $class_name['total_add_point'];
	$chart['total_subtr_point'][$class] = $class_name['total_subtr_point'];
}
define('db_id', $_SESSION['db_id']);
$tpl = new XTemplate('template/chart.tpl');
@$tpl->assign('total_point', Chart::bar($chart['total_point'], false));
@$tpl->assign('total_add_point', Chart::bar($chart['total_add_point'], false));
@$tpl->assign('total_subtr_point', Chart::bar($chart['total_subtr_point'], false));
$tpl->parse('main');
$tpl->out('main');
unset($_SESSION['chart']);
unset($_SESSION['db_id']);
?>