﻿<?php/*	Hỗ trợ chức năng tạo biểu đồ cột*/
class Chart {
	function bar($data, $percentage) {
		$bar_black = '
			<dt style="left: %1$s%%; width: %5$s%%;"><a href="class_rank.php?action=more_detail&db_id='.db_id.'&class=%4$s" target="blank_">%4$s</a></dt>
			<dd style="left: %1$s%%; width: %5$s%%; height: %3$s%%;"><b><span style="color: black;">%2$s</span></b></dd>
			';
		$bar = '
			<dt style="left: %1$s%%; width: %5$s%%;"><a href="class_rank.php?action=more_detail&db_id='.db_id.'&class=%4$s" target="blank_">%4$s</a></dt>
			<dd style="left: %1$s%%; width: %5$s%%; height: %3$s%%;"><b>%2$s</b></dd>
			';
		$wrap = '<dl class="chart">%s</dl>';
		$output = '';
		$max = max($data);
		if($percentage and (($max > 100) or ($max < 0))) {
			trigger_error('Chỉ số phần trăm tối đa phải nằm trong khoảng từ 0% đến 100%');
		}
		$i = 0;
		$total = count($data);
		foreach($data as $key => $val) {
			$spacing = round($total / ($total ^ 2), 2);
			$left = round($spacing + ((100 / $total) * $i), 2);
			$height = round($percentage ? $val : (($val / $max) * 100), 2);
			$width = round((100 / $total) - ($spacing * 2), 2);
			if ($val < 0 ) {
				$output .= sprintf($bar_black, $left, $val, $height, $key, $width, db_id);
			} else {
				$output .= sprintf($bar, $left, $val, $height, $key, $width);
				}
			$i ++;
		}
		return sprintf($wrap, $output);
	}
}
?>