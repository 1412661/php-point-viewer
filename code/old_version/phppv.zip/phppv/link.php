<?php

include_once('config/config.php');

if ((isset($_GET['link'])) and (!empty($_GET['link']))) {
	$link = base64_decode($_GET['link']);

	header('Location: '.$link);
} else {
	header('Location: '.SITE);
}

?>
